const URL = 'http://172.28.0.202:8000'
const container = document.querySelector(`.container`)

const burgerContent = document.querySelector(`.burger-content`)
const inpSearch = document.querySelector(`#inp-search`)

const searchContent = document.querySelector(`.search-content`)




const token = () => {
  return localStorage.getItem('token')
}
const getData = async (url, method, body) => {
  
  const req = await fetch(url, {
    method: method,
    body: body,
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token()}`,
    },
  })
  try {
    const resp = await req.json();
    console.log(resp);
    return resp;
  }
  catch (err) {
    console.log(err);
  }
}
const end = {
  allUsers: '/users?skip=0&limit=100', //get
  createUser: '/users', //post
  login: '/users/login', //post
  createChat: '/chat', //post
  myChats: '/chat/my', //get
  sendMessage: '/send_message', //post
  getMessages: '/get_data', //get
}



const log = await getData(URL + end.login, 'POST', JSON.stringify({ email: 'testNewFunc', password: '12345678' })) // надо заменить на логин
localStorage.setItem('token', log.access_token)


// отрисовка чатов в поиске
const showAllUsers = async () => {
  searchContent.innerHTML = '';
  const all = await getData(URL + end.allUsers, 'GET',)
  all.forEach(element => {
    const card = `
    <li class="search-result" id=${element.id}>
    <img src="images/user (2).png" alt="#">
    <h2>${element.email}</h2>
    </li>
    `
    searchContent.insertAdjacentHTML('beforeend', card)
  });
  
}

// отрисовка чатов пользователя
const renderMyChats = async () => {
  document.querySelector('.chats').innerHTML = '';
  const ownChats = await getData(URL + end.myChats, 'GET',)
  ownChats.chats.forEach(element => {
    const chat = `
    <div class="chat" id="chat_id:${element.id}">
    <img src="images/user (2).png" alt="#">
    <h2 id="to_user_id:${element.to_user.id}">${element.to_user.email}</h2>
    </div>
    <hr>
    `
    document.querySelector('.chats').insertAdjacentHTML('afterbegin', chat)
  })
}

// не удалять
// создание нового чата
const createChat = async (id) => {
  await getData(URL + end.createChat + `/${id}`, 'POST', '')
  renderMyChats();
  
  // if (!chat.detail) {
    //   chat = await getData(URL + end.getMessages + `/${id}`, 'GET',)
    // }
    // const chatContent = `
    //   <div class="chat-header">
    //     <div class="chat-header-right">
    //         <img class="chat-header-right-img" src="images/user (2).png" alt="#">
  //         <h2 class="chat-header-right-h2">Название чата</h2>
  //     </div>
  //   </div>
  //   <div class="chat-middle">
  //     <div class="message1">
  //       <p class="message2">
  //         JOOOOOOOOOOOHN Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio optio possimus
  //         molestias atque vitae, eligendi ipsam? Cumque, quidem eum! Minima eum, laudantium quia rerum
  //         possimus expedita explicabo facilis non repellendus. Lorem ipsum dolor, sit amet consectetur
  //         adipisicing elit. Numquam, tempora! Est exercitationem repudiandae voluptas numquam
  //         nesciunt, consectetur distinctio nam non assumenda nobis, ad sit ullam quo? Nihil id ipsam
  //         quod?
  //       </p>
  //     </div>
  //     <div class="message1">
  //       <p class="message2">
  //         JOOOOOOOOOOOHN
  //       </p>
  //     </div>
  //     <div class="message1">
  //       <p class="message2">
  //         JOOOOOOOOOOOHN
  //       </p>
  //     </div>
  //   </div>
  // <div class="chat-footer">
  //   <input class="chat-footer-inp" type="text" placeholder="Введите сообщение">
  //   <img class="chat-footer-img"
  //       src="https://raw.githubusercontent.com/zenkaster/messenger/Maksim/Maxim/images/send-mes-img.png"
  //       alt="#">
  // </div>
  // `
}





const init = () => {
  renderMyChats();
}
init()


document.addEventListener('click', (e) => {
  const target = e.target;
  // console.log(target);
  if (target.closest('.burger-menu')) {
    burgerContent.classList.toggle(`hide`)
  }
  if (!burgerContent.classList.contains('hide') && !target.closest('.burger-menu')&& !target.closest('.burger-content')) {
    burgerContent.classList.toggle(`hide`)
  }
  if (target.closest(`#inp-search`)) {
    searchContent.classList.toggle(`hide`);
    showAllUsers();
  }
  if (!searchContent.classList.contains('hide') && !target.closest('#inp-search')) {
    searchContent.classList.toggle(`hide`);
  }
  if (target.closest('.chat-search')) {
    createChat(target.id);
  }
})

const sideCheckbox = document.querySelector(`#side-checkbox`)
const link = document.getElementById("theme-link");

sideCheckbox.addEventListener(`click`, (e) => {
  let lightTheme = "./dist/style.css";
  let darkTheme = "./dist/light-style.css";
  console.log(link);

  let currTheme = link.getAttribute("href");
  let theme = "";
  if(sideCheckbox.checked) {
    currTheme = darkTheme;
   	theme = "dark";
  }
  else {
    currTheme = lightTheme;
   	theme = "light";
  }

  link.setAttribute("href", currTheme);

  // Save(theme);
})

const endCreateUser = "/users";
const endCreateChat = "/create_chat";
const endLogin = "/users/login";
const endSendMess = "/send_message";

/////////////////////
const formWrap = document.querySelector(".form-wrapper");
const title = document.querySelector("#form-title");
const logo = document.querySelector("#form-logo");
////

const entrLink = document.querySelector("#entrance");
const registrSend = document.querySelector("#registr-send");
const registrForm = document.querySelector(".registration-form");
const entrForm = document.querySelector(".entrance-form");
const wrapper = document.querySelector(".wrapper");
const already = document.querySelector(".already-block");

/////////////////////

const regMail = document.querySelector("#registr-mail");
const regLogin = document.querySelector("#registr-login");
const regPass = document.querySelector("#registr-password");
const regRepeat = document.querySelector("#registr-repeat");

//entr

const entrLogin = document.querySelector("#entrance-login");
const entrPass = document.querySelector("#entrance-password");
const entrBtn = document.querySelector("#entr-send");

//error
const regErrMail = document.querySelector("#error-reg-mail");
const regErrLog = document.querySelector("#error-reg-log");
const regErrPas = document.querySelector("#error-reg-pas");
const regErrRep = document.querySelector("#error-reg-rep");

/////////////////////

let regMailValue = 0;
let regLogValue = 0;
let regPassValue = 0;
let regRepValue = 0;

/////////////////////

const registredTitle = document.querySelector(".registred-title");
///

const entrError = document.querySelector("#entrance-error");
const regTitle = document.querySelector(".entr-title");

////

const createUser = async (login, password) => {
  const data = await fetch(url + endCreateUser, {
    method: "POST",
    body: `grant_type=&username=${body.user}`,

    headers: {
      accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email: login,
      password: password,
    }),
  });
  try {
    const req = await data.json();
    console.log(req);
    return req;
  } catch (error) {
    console.error(error);
  }
};

///

const loginUser = async () => {
  const data = await fetch(url + endLogin, {
    method: "POST",
    headers: {
      accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email: entrLogin.value,
      password: entrPass.value,
    }),
  });
  try {
    const resp = await data.json();
    if (resp.access_token) {
      return resp.access_token;
    }
    return resp.detail;
  } catch (err) {
    console.log(err);
  }
};
//

regMail.addEventListener("blur", () => {
  regMailValue = 0;
  regErrMail.classList.remove("error-true");
  regMail.style.borderBottom = "2px solid red";
  if (regMail.value.length == 0) {
    regErrMail.textContent = "Обязательное поле";
  } else {
    if (/^[\w.-]+@[a-zA-Z_-]+?(?:\.[a-zA-Z]{2,6})+$/.test(regMail.value)) {
      if (regMail.value.length > 4) {
        regErrMail.textContent = "✓";
        regErrMail.classList.add("error-true");
        regMailValue = 1;
        regMail.style.borderBottom = "2px solid green";
      } else {
        regErrMail.textContent = "Слишком короткий email";
      }
    } else {
      9;
      regErrMail.textContent = "Неккоретный email";
    }
  }
  if (
    regLogValue == 1 &&
    regPassValue == 1 &&
    regRepValue == 1 &&
    regMailValue == 1
  ) {
    registrSend.classList.add("active");
  } else {
    registrSend.classList.remove("active");
  }

});
///
regLogin.addEventListener("blur", () => {
  regLogValue = 0;
  regErrLog.classList.remove("error-true");
  regLogin.style.borderBottom = "2px solid red";
  const logValue = regLogin.value.length;
  if (logValue == 0) {
    regErrLog.textContent = "Обязательное поле";
  } else {
    if (logValue >= 3 && logValue <= 15) {
      if (/^[a-zA-Z]+$/.test(regLogin.value)) {
        if (/^[A-Z].*$/.test(regLogin.value)) {
          regLogValue = 1;
          regLogin.style.borderBottom = "2px solid green";
          regErrLog.classList.add("error-true");
          regErrLog.textContent = "✓";
        } else {
          regErrLog.textContent = "Первый символ - заглавная буква";
        }
      } else {
        regErrLog.textContent = "Только латинские символы";
      }
    } else {
      regErrLog.textContent = "Кол-во символов: от 3 до 15";
    }
    if (
      regLogValue == 1 &&
      regPassValue == 1 &&
      regRepValue == 1 &&
      regMailValue == 1
    ) {
      registrSend.classList.add("active");
    } else {
      registrSend.classList.remove("active");
    }
  }

});
//
regPass.addEventListener("blur", () => {
  regPassValue = 0;
  const passValue = regPass.value.length;
  regPass.style.borderBottom = "2px solid red";
  regErrPas.classList.remove("error-true");

  if (passValue == 0) {
    regErrPas.textContent = "Обязательное поле";
  } else {
    if (passValue >= 5 && passValue <= 15) {
      regErrPas.classList.add("error-true");
      regPass.style.borderBottom = "2px solid green";

      if (
        /^[0-9]+$|^[a-z]+$/.test(regPass.value) ||
        /^[0-9a-z]+$/.test(regPass.value)
      ) {
        regPassValue = 1;

        regErrPas.textContent = "Простой пароль ✓";
        regErrPas.style.fontSize = "16px";
      } else {
        regPassValue = 1;

        regErrPas.textContent = "Сложный пароль ✓";
        regErrPas.style.fontSize = "16px";
      }
    } else {
      regErrPas.textContent = "Кол-во символов: от 5 до 15";
    }
    if (regRepeat.value.length >= 5) {
      if (regRepeat.value === regPass.value) {
        regErrRep.textContent = "Пароли совпадают ✓";
        regRepValue = 1;
        regErrRep.classList.add("error-true");
        regRepeat.style.borderBottom = "2px solid green";
        regErrRep.style.fontSize = "16px";
      } else {
        regErrRep.classList.remove("error-true");
        regErrRep.textContent = "Пароли не совпадают";
        regRepValue = 0;
      }
    }
    if (
      regLogValue == 1 &&
      regPassValue == 1 &&
      regRepValue == 1 &&
      regMailValue == 1
    ) {
      registrSend.classList.add("active");
    } else {
      registrSend.classList.remove("active");
    }
  }
});

regRepeat.addEventListener("blur", () => {
  regRepValue = 0;
  regRepeat.style.borderBottom = "2px solid red";
  regErrRep.classList.remove("error-true");
  const repValue = regRepeat.value.length;
  if (regRepeat.value == 0) {
    regErrRep.textContent = "Обязательное поле";
  } else {
    if (repValue >= 5 && repValue <= 15) {
      if (regRepeat.value == regPass.value) {
        regRepValue = 1;
        regErrRep.classList.add("error-true");
        regRepeat.style.borderBottom = "2px solid green";
        regErrRep.style.fontSize = "16px";

        regErrRep.textContent = "Пароли совпадают ✓";
        if (
          regLogValue == 1 &&
          regPassValue == 1 &&
          regRepValue == 1 &&
          regMailValue == 1
        ) {
          registrSend.classList.add("active");
        } else {
          registrSend.classList.remove("active");
        }
      } else {
        regErrRep.textContent = "Пароли не совпадают";
      }
    } else {
      regErrRep.textContent = "Кол-во символов: от 5 до 15";
    }
  }
});

///////

registrSend.addEventListener("click", async (e) => {
  e.preventDefault();
  if (
    regLogValue == 1 &&
    regPassValue == 1 &&
    regRepValue == 1 &&
    regMailValue == 1
  ) {
    const res = await createUser(regLogin.value, regPass.value);
    if (res.detail) {
      regErrLog.style.color = "red";
      regLogin.style.borderBottom = "2px solid red";
      regErrLog.style.fontSize = "14px";
      regErrLog.textContent = "Такой логин уже есть";
    } else {
      registredTitle.style.display = "block";
      registrForm.style.display = "none";
      already.style.display = "none";
      setTimeout(() => {
        registredTitle.style.display = "none";
        entrForm.style.display = "flex";
      }, 4000);
    }
  } else {
    alert("Значения невалидны");
  }
});

//
let entrLogVal = 0;
let entrPasVal = 0;

entrLogin.addEventListener("blur", () => {
  const entrLogValue = entrLogin.value;
  if (entrLogValue.length > 0) {
    if (entrLogValue.length >= 3 && entrLogValue.length <= 15) {
      if (/^[a-zA-Z]+$/.test(entrLogValue)) {
        if (/^[A-Z].*$/.test(entrLogValue)) {
          regLogin.style.borderBottom = "2px solid green";
          regErrLog.classList.add("error-true");
          regErrLog.textContent = "✓";
        } else {
          regErrLog.textContent = "Первый символ - заглавная буква";
        }
      } else {
        regErrLog.textContent = "Только латинские символы";
      }
    }
  }
});
entrPass.addEventListener("blur", () => {});

const entrFormOpening = () => {
  formWrap.style.transform = "rotateY(180deg)";

  setTimeout(() => {
    registrForm.style.display = "none";
    already.style.display = "none";
    entrForm.style.display = "flex";
    title.style.transform = "rotateY(180deg)";
    logo.style.transform = "rotateY(180deg)";
  }, 500);
};

entrLink.addEventListener("click", entrFormOpening);

entrBtn.addEventListener("click", async (e) => {
  e.preventDefault();
  const guest = entrLogin.value;
  const token = await loginUser();
  if (token == "Incorrect username or password") {
    entrLogin.style.borderBottom = "2px solid red";
    entrPass.style.borderBottom = "2px solid red";
    entrError.textContent = "Неправильный логин или пароль";
    entrError.style.display = "block";
  } else {
    localStorage.setItem("token", token);
    console.log(token);
    already.style.display = "none";
    entrForm.style.display = "none";
    regTitle.style.display = "block";
    regTitle.textContent = `Добро пожаловать, ${guest}`;
    setTimeout(() => {
      wrapper.style.display = "none";
    }, 3000);
  }
  entrLogin.value = "";
  entrPass.value = "";
});